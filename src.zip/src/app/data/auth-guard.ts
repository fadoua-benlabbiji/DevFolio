import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { UserService } from './user';

export const authGuard: CanActivateFn = (route,State) => {
  const userService = inject(UserService);
  const router = inject(Router);
  //teste de connexion
  if (userService.isLoggedIn()) {
    return true;
  }
  //redirection 
  return router.createUrlTree(['/connexion']);
};