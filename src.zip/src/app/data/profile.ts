import { Injectable, signal, computed, inject } from '@angular/core';
import { Profile } from './profile.model';
import { UserService } from './user';

export interface Education {
  id: number;
  profileId: number;
  diplome: string;
  etablissement: string;
  debut: string;
  fin: string;
}

@Injectable({ providedIn: 'root' })
export class ProfileService {
  private userService = inject(UserService);
  private _profiles = signal<Profile[]>(MOCK_PROFILES);
  readonly profiles = this._profiles.asReadonly();

  // ── Formations ────────────────────────────────────────────────────────────
  private _educations = signal<Education[]>([
    {
      id: 1, profileId: 1,
      diplome: 'Licence en Informatique',
      etablissement: 'Université Hassan II',
      debut: '2020', fin: '2023',
    },
    {
      id: 2, profileId: 1,
      diplome: 'Master Génie Logiciel',
      etablissement: 'ENSIAS',
      debut: '2023', fin: 'En cours',
    },
  ]);

  readonly myProfile = computed(() => {
    const u = this.userService.currentUser();
    if (!u) return MOCK_PROFILES[0];
    return this._profiles().find(p => p.id === u.profileId) ?? MOCK_PROFILES[0];
  });

  // ── Formations du profil connecté ─────────────────────────────────────────
  readonly myEducations = computed(() => {
    const profile = this.myProfile();
    if (!profile) return [];
    return this._educations().filter(e => e.profileId === profile.id);
  });

  // ── CRUD Formations ───────────────────────────────────────────────────────
  addEducation(edu: Omit<Education, 'id' | 'profileId'>): void {
    const profile = this.myProfile();
    if (!profile) return;
    this._educations.update(list => [
      ...list,
      { ...edu, id: Date.now(), profileId: profile.id },
    ]);
  }

  updateEducation(id: number, changes: Partial<Education>): void {
    this._educations.update(list =>
      list.map(e => e.id === id ? { ...e, ...changes } : e)
    );
  }

  removeEducation(id: number): void {
    this._educations.update(list => list.filter(e => e.id !== id));
  }

  // ── Profils ───────────────────────────────────────────────────────────────
  addProfile(profile: Profile): void {
    this._profiles.update(list => [...list, profile]);
  }

  updateProfile(updatedProfile: Profile): void {
    this._profiles.update(list =>
      list.map(p => p.id === updatedProfile.id ? updatedProfile : p)
    );
  }

  update(id: number, changes: Partial<Profile>): void {
    this._profiles.update(list =>
      list.map(p => p.id === id ? { ...p, ...changes } : p)
    );
  }

  getAll(): Profile[] { return this._profiles(); }
  getById(id: number): Profile | undefined { return this._profiles().find(p => p.id === id); }
  getBySkill(skill: string): Profile[] { return this._profiles().filter(p => p.skills.includes(skill)); }
  search(query: string): Profile[] {
    const q = query.toLowerCase();
    return this._profiles().filter(p =>
      p.nom.toLowerCase().includes(q) ||
      p.titre.toLowerCase().includes(q) ||
      p.ville.toLowerCase().includes(q) ||
      p.skills.some(s => s.toLowerCase().includes(q))
    );
  }
}

const MOCK_PROFILES: Profile[] = [
  {
    id: 1, nom: 'Lina Bensalem', username: 'lina-dev', email: 'lina@example.com',
    titre: 'Développeuse Full Stack',
    bio: 'Passionnée par Angular, Node.js et les architectures scalables.',
    ville: 'Casablanca', projets: 12, featured: true,
    avatar: 'https://i.pravatar.cc/80?img=12',
    skills: ['Angular', 'Node.js', 'MongoDB', 'TypeScript'],
    github: '#', linkedin: '#', website: '#',
  },
  {
    id: 2, nom: 'Sara Bennani', username: 'sara-bennani', email: 'sara@example.com',
    titre: 'Frontend Engineer',
    bio: "Spécialisée en UI/UX et React. J'aime créer des interfaces accessibles.",
    ville: 'Rabat', projets: 8, featured: false,
    avatar: 'https://i.pravatar.cc/80?img=32',
    skills: ['React', 'TypeScript', 'CSS', 'Figma'],
    github: '#', linkedin: '#', website: '#',
  },
];