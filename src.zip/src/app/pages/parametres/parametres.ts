import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../data/user';
import { ProfileService } from '../../data/profile';
import { Profile } from '../../data/profile.model';

interface Education {
  id: number | null;
  diplome: string;
  etablissement: string;
  debut: string;
  fin: string;
}

const EMPTY_EDU_FORM = (): Education => ({
  id: null,
  diplome: '',
  etablissement: '',
  debut: '',
  fin: ''
});

@Component({
  selector: 'app-parametres',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './parametres.html',
  styleUrl: './parametres.css'
})
export class Parametres implements OnInit {
  private userService    = inject(UserService);
  private profileService = inject(ProfileService);

  readonly currentUser = this.userService.currentUser;

  saved     = signal(false);
  activeTab = signal<'profil' | 'confidentialite' | 'notifications'>('profil');

  // Champs du formulaire profil
  avatarUrl  = signal('');
  nomComplet = signal('');
  username   = signal('');
  titre      = signal('');
  bio        = signal('');
  email      = signal('');
  ville      = signal('');
  github     = signal('');
  linkedin   = signal('');
  website    = signal('');

  // ── Formations / Éducation ────────────────────────────────────────────────
  educations  = signal<Education[]>([]);
  showEduForm = signal(false);
  eduForm     = signal<Education>(EMPTY_EDU_FORM());

  openAddEdu(): void {
    this.eduForm.set(EMPTY_EDU_FORM());
    this.showEduForm.set(true);
  }

  openEditEdu(edu: Education): void {
    this.eduForm.set({ ...edu });
    this.showEduForm.set(true);
  }

  setEduField(field: keyof Omit<Education, 'id'>, value: string): void {
    this.eduForm.update(f => ({ ...f, [field]: value }));
  }

  saveEdu(): void {
    const form = this.eduForm();
    if (!form.diplome.trim()) return;

    if (form.id !== null) {
      // Modification
      this.educations.update(list =>
        list.map(e => e.id === form.id ? { ...form } : e)
      );
    } else {
      // Ajout
      this.educations.update(list => [
        ...list,
        { ...form, id: Date.now() }
      ]);
    }

    this.cancelEdu();
  }

  deleteEdu(id: number | null): void {
    if (id === null) return;
    this.educations.update(list => list.filter(e => e.id !== id));
  }

  cancelEdu(): void {
    this.showEduForm.set(false);
    this.eduForm.set(EMPTY_EDU_FORM());
  }

  // ── Confidentialité ───────────────────────────────────────────────────────
  profileVisibility  = signal<'public' | 'private' | 'connections'>('public');
  showEmail          = signal(false);
  showGithub         = signal(true);
  indexSearchEngines = signal(true);

  // ── Notifications ─────────────────────────────────────────────────────────
  emailNotifs   = signal(true);
  messageNotifs = signal(true);
  weeklyDigest  = signal(false);
  projectViews  = signal(true);

  readonly tabs = [
    { id: 'profil',          label: 'Profil',          icon: 'user'   },
    { id: 'confidentialite', label: 'Confidentialité', icon: 'shield' },
    { id: 'notifications',   label: 'Notifications',   icon: 'bell'   },
  ] as const;

  readonly profileCompleteness = computed(() => {
    let score = 0;
    if (this.nomComplet())  score += 20;
    if (this.username())    score += 20;
    if (this.titre())       score += 20;
    if (this.bio())         score += 20;
    if (this.avatarUrl())   score += 20;
    return score;
  });

  ngOnInit(): void {
    const profile = this.profileService.myProfile();
    if (!profile) return;

    this.avatarUrl.set(profile.avatar   ?? '');
    this.nomComplet.set(profile.nom     ?? '');
    this.username.set(profile.username  ?? '');
    this.titre.set(profile.titre        ?? '');
    this.bio.set(profile.bio            ?? '');
    this.email.set(profile.email        ?? '');
    this.ville.set(profile.ville        ?? '');
    this.github.set(profile.github      ?? '');
    this.linkedin.set(profile.linkedin  ?? '');
    this.website.set(profile.website    ?? '');
  }

  setTab(tab: 'profil' | 'confidentialite' | 'notifications'): void {
    this.activeTab.set(tab);
  }

  save(): void {
    const profile = this.profileService.myProfile();
    if (!profile) return;

    const updated: Profile = {
      ...profile,
      avatar:   this.avatarUrl(),
      nom:      this.nomComplet(),
      username: this.username(),
      titre:    this.titre(),
      bio:      this.bio(),
      email:    this.email(),
      ville:    this.ville(),
      github:   this.github(),
      linkedin: this.linkedin(),
      website:  this.website(),
    };

    this.profileService.updateProfile(updated);
    this.saved.set(true);
    setTimeout(() => this.saved.set(false), 2500);
  }
}